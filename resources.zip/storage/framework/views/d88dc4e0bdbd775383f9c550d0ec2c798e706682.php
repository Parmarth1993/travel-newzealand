
<?php $__env->startSection('content'); ?>
<div id="page-content-wrapper">
   <section class="maindiv">
      <div class="container">
         <div class="row headingtop">
            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
               <h2 class="textlog">Add New Itinerarie</h2>
            </div>
         </div>
         <div class="row">
            <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger text-center')); ?>">
               <?php echo e(Session::get('error')); ?>

            </p>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-success text-center')); ?>">
               <?php echo e(Session::get('success')); ?>

            </p>
            <?php endif; ?>
         </div>
         <form action="<?php echo e(route('add_itinerarie')); ?>" name="profile_form" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                  <div class="form-group">
                     <label>Name</label>
                     <input type="text" name="name" class="form-control" value="" required>
                  </div>
                  <div class="form-group">
                     <label>Description</label>
                     <textarea name="description" class="form-control" value="" required></textarea>
                  </div>
                  <input type="submit" name="" class="btn btn-primary ml-auto" value="Add Accomodation">
               </div>
            </div>
         </form>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Atx\travel-newzealand\resources\views/admin/add-itinerarie.blade.php ENDPATH**/ ?>