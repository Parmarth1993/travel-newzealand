
<?php $__env->startSection('content'); ?>
<div id="page-content-wrapper">
   <section class="maindiv">
      <div class="container">
         <div class="row headingtop">
            <div class="col-lg-4 col-md-4 col-sm-4 col-12">
               <h2 class="textlog">Accomodations</h2>
            </div>
         </div>
         <div class="row">
            <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger text-center')); ?>">
               <?php echo e(Session::get('error')); ?>

            </p>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-success text-center')); ?>">
               <?php echo e(Session::get('success')); ?>

            </p>
            <?php endif; ?>
         </div>
         <div class="form-group d-flex">                                
            <a href="/admin/accomodation/add" class="btn btn-primary ml-auto" >Add Accomodation</a>
         </div>
         <div class="card shadow mb-4">
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0">
                     <thead>
                        <tr>
                           <th>Name</th>
                           <th>Description</th>
                           <th>Actions</th>
                        </tr>
                     </thead>
                     <tfoot>
                        <tr>
                           <th>Name</th>
                           <th>Description</th>
                           <th>Actions</th>
                        </tr>
                     </tfoot>
                     <tbody>
                        <?php $__currentLoopData = $accomodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="plan-<?php echo e($accomodation->id); ?>">
                           <td><?php echo e($accomodation->name); ?></td>
                           <td><?php echo e($accomodation->description); ?></td>
                           <td>
                              <a href="/admin/accomodation/edit/<?php echo e($accomodation->id); ?>" >Edit</a>
                              <a href="javascript:vood(0);" data-id="<?php echo e($accomodation->id); ?>" class="delete-plan">Delete</a>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travel-newzealand\resources\views/admin/accomodations.blade.php ENDPATH**/ ?>