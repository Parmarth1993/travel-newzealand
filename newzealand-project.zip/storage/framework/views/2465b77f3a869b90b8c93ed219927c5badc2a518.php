
<?php $__env->startSection('content'); ?>
<div id="page-content-wrapper">
   <section class="maindiv">
      <div class="container">
         <div class="row headingtop">
            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
               <h2 class="textlog">Add New Property</h2>
            </div>
         </div>
         <div class="row">
            <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger text-center')); ?>">
               <?php echo e(Session::get('error')); ?>

            </p>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-success text-center')); ?>">
               <?php echo e(Session::get('success')); ?>

            </p>
            <?php endif; ?>
         </div>
         <form action="<?php echo e(route('edit_properties', $property->id)); ?>" name="profile_form" enctype='multipart/form-data' method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                  <div class="form-group">
                     <label>Name</label>
                     <input type="text" name="name" class="form-control" value="<?php echo e($property->name); ?>" required>
                  </div>
                  <div class="form-group">
                     <label>Description</label>
                     <textarea name="description" class="form-control" required><?php echo e($property->description); ?></textarea>
                  </div>
                  <div class="form-group">
                     <label>Select Logo</label>
                     <input type="file" name="logo" id="file-upload" class="file">
                     <input type="hidden" name="logo2" value="<?php echo e($property->logo); ?>">
                     <img src="/uploads/profiles/<?php echo e($property->logo); ?>" width="150" style="border: 1px solid #000">
                  </div>
                  <div class="form-group">
                     <label>Select Accomodation</label>
                     <select name="accommodation" class="form-control">
                        <option value="">Select Accomodation</option>
                        <?php $__currentLoopData = $accomodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($accomodation->id); ?>" <?php if($accomodation->id == $property->accommodation): ?> selected='selected' <?php endif; ?>><?php echo e($accomodation->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label>Select Highlight</label>
                     <select name="highlight" class="form-control">
                        <option value="">Select Highlight</option>
                        <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($highlight->id); ?>"  <?php if($highlight->id == $property->highlight): ?> selected='selected' <?php endif; ?>><?php echo e($highlight->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label>Select Itineraries</label>
                     <select name="itineraries" class="form-control">
                        <option value="">Select Itineraries</option>
                        <?php $__currentLoopData = $itineraries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itinerary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($itinerary->id); ?>"  <?php if($itinerary->id == $property->itineraries): ?> selected='selected' <?php endif; ?>><?php echo e($itinerary->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label>Select Activities</label>
                     <input type="checkbox" name="activities[]" value="Helicopter" <?php if(in_array("Helicopter", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Helicopter
                     <input type="checkbox" name="activities[]" value="Hili Area" <?php if(in_array("Hili Area", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Hili Area
                     <input type="checkbox" name="activities[]" value="Fishing" <?php if(in_array("Fishing", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Fishing
                     <input type="checkbox" name="activities[]" value="Food" <?php if(in_array("Food", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Food
                     <input type="checkbox" name="activities[]" value="Army" <?php if(in_array("Army", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Army
                     <input type="checkbox" name="activities[]" value="Religion" <?php if(in_array("Religion", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Religion
                     <input type="checkbox" name="activities[]" value="Videos" <?php if(in_array("Videos", unserialize($property->activities))) { echo 'checked="checked"'; }?>>Videos
                  </div>
                  <div class="form-group">
                     <label>Select Type</label>
                     <select name="type" class="form-control" required>
                        <option value="">Select Type</option>
                        <option value="Luxury" <?php if("Luxury" == $property->type): ?> selected='selected' <?php endif; ?>>Luxury</option>
                        <option value="Premium" <?php if("Premium" == $property->type): ?> selected='selected' <?php endif; ?>>Premium</option>
                     </select>
                  </div>
                  <input type="submit" name="" class="btn btn-primary ml-auto" value="Add Property">
               </div>
            </div>
         </form>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travel-newzealand\resources\views/admin/edit-property.blade.php ENDPATH**/ ?>