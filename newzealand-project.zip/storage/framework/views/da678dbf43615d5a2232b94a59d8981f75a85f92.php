

<?php $__env->startSection('content'); ?>
<div id="page-content-wrapper">
   <section class="maindiv">
      <div class="container">
         <div class="row headingtop">
            <div class="col-lg-4 col-md-4 col-sm-4 col-12">
               <h2 class="textlog">Dashboard</h2>
            </div>            
         </div>
         <div class="row">
         	<?php if(Session::has('error')): ?>
              <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger text-center')); ?>">
                 <?php echo e(Session::get('error')); ?>

              </p>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
              <p class="alert <?php echo e(Session::get('alert-class', 'alert-success text-center')); ?>">
                 <?php echo e(Session::get('success')); ?>

              </p>
            <?php endif; ?>

            <!-- calendar -->
            
         </div>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travel-newzealand\resources\views/admin/index.blade.php ENDPATH**/ ?>